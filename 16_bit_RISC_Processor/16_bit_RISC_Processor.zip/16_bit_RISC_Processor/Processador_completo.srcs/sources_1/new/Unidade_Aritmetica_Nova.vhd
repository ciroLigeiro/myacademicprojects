library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Unidade_Aritmetica is
    port (
        a, b       : in  STD_LOGIC_VECTOR(15 downto 0); -- Entradas A e B
        op         : in  std_logic;                     -- 0=Soma, 1=Subtração
        y          : out STD_LOGIC_VECTOR(15 downto 0); -- Resultado
        C, O, Z, N : out std_logic                      -- Flags
    );
end Unidade_Aritmetica;

architecture Behavioral of Unidade_Aritmetica is
    -- Sinais de 17 bits para lidar com o Carry
    signal a_ext, b_ext, res_ext : std_logic_vector(16 downto 0);
    signal op_vec : std_logic_vector(16 downto 0);
    signal carry_in : std_logic_vector(16 downto 0);
begin

    -- 1. Extensão de sinal (Bit 16 = Bit 15)
    a_ext(15 downto 0) <= a;
    a_ext(16)          <= a(15); -- Extensão de sinal do A

    b_ext(15 downto 0) <= b;
    b_ext(16)          <= b(15); -- Extensão de sinal do B

    -- 2. Vetor de operação (para fazer XOR no B se for subtração)
    op_vec <= (others => op);
    
    -- 3. Carry In (Se op=1, somamos 1 para fazer complemento para 2)
    carry_in(16 downto 1) <= (others => '0');
    carry_in(0) <= op;
    res_ext <= std_logic_vector(signed(a_ext) + signed(b_ext xor op_vec) + signed(carry_in));

    -- 4. Saídas
    y <= res_ext(15 downto 0);

    -- 5. Flags
    C <= res_ext(16) xor op; -- Carry Out
    N <= res_ext(15);        -- Negative (Bit de sinal)
    Z <= '1' when res_ext(15 downto 0) = x"0000" else '0'; -- Zero

    -- Overflow (Sinal dos operandos vs Sinal do resultado)
    O <= (not res_ext(15) and a(15) and (op xor b(15))) or 
         (res_ext(15) and not a(15) and not (op xor b(15)));

end Behavioral;