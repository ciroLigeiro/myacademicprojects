library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Processador_Completo is
    Port ( 
        Clock       : in  STD_LOGIC;
        Reset       : in  STD_LOGIC;
        Instruction : in  STD_LOGIC_VECTOR (15 downto 0);
        Output_Data : out STD_LOGIC_VECTOR (15 downto 0)
    );
end Processador_Completo;

architecture Structural of Processador_Completo is

    -- COMPONENTES

    component Unidade_Controlo
        Port (
            Instruction : in  STD_LOGIC_VECTOR (15 downto 0);
            Rd_addr     : out STD_LOGIC_VECTOR (2 downto 0);
            Rs1_addr    : out STD_LOGIC_VECTOR (2 downto 0);
            Rs2_addr    : out STD_LOGIC_VECTOR (2 downto 0);
            RegWrite    : out STD_LOGIC;
            OpCode_ALU  : out STD_LOGIC_VECTOR (3 downto 0);
            ALU_Src     : out STD_LOGIC;
            Imm_8bit    : out STD_LOGIC_VECTOR (7 downto 0);
            MemWrite    : out STD_LOGIC          -- WriteEnable
        );
    end component;

    component Banco_Registos
        Port ( 
            Clock     : in STD_LOGIC;
            Reset     : in STD_LOGIC;
            RegWrite  : in STD_LOGIC;
            Rs1       : in STD_LOGIC_VECTOR (2 downto 0);
            Rs2       : in STD_LOGIC_VECTOR (2 downto 0);
            Rd        : in STD_LOGIC_VECTOR (2 downto 0);
            Data_In   : in STD_LOGIC_VECTOR (15 downto 0);
            Data_Out1 : out STD_LOGIC_VECTOR (15 downto 0);
            Data_Out2 : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    component Extensao_Sinal
        Port ( 
            Data_In  : in  STD_LOGIC_VECTOR (7 downto 0);
            Data_Out : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    component MUX2
        Port ( 
            Sel : in  STD_LOGIC;
            A   : in  STD_LOGIC_VECTOR (15 downto 0);
            B   : in  STD_LOGIC_VECTOR (15 downto 0);
            Y   : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    component ALU_Completa
        Port (
            A_in      : in  STD_LOGIC_VECTOR(15 downto 0);
            B_in      : in  STD_LOGIC_VECTOR(15 downto 0);
            OpCode_in : in  STD_LOGIC_VECTOR(3 downto 0);
            R_out     : out STD_LOGIC_VECTOR(15 downto 0);
            Z_flag    : out STD_LOGIC;
            N_flag    : out STD_LOGIC;
            O_flag    : out STD_LOGIC;
            C_flag    : out STD_LOGIC
        );
    end component;

    component Memoria_Dados
        Port (
            Addr        : in  STD_LOGIC_VECTOR (15 downto 0);
            WriteData   : in  STD_LOGIC_VECTOR (15 downto 0);
            WriteEnable : in  STD_LOGIC;
            ReadData    : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    -- SINAIS INTERNOS

    signal s_RegWrite  : std_logic;
    signal s_MemWrite  : std_logic;
    signal s_ALU_Src   : std_logic;

    signal s_OpCode_ALU : std_logic_vector(3 downto 0);

    signal s_Rd_addr  : std_logic_vector(2 downto 0);
    signal s_Rs1_addr : std_logic_vector(2 downto 0);
    signal s_Rs2_addr : std_logic_vector(2 downto 0);

    signal s_Imm_8bit : std_logic_vector(7 downto 0);
    signal s_Imm_Ext  : std_logic_vector(15 downto 0);

    signal s_Read1    : std_logic_vector(15 downto 0);
    signal s_Read2    : std_logic_vector(15 downto 0);

    signal s_ALU_B    : std_logic_vector(15 downto 0);
    signal s_ALU_Res  : std_logic_vector(15 downto 0);

    signal s_Mem_Out  : std_logic_vector(15 downto 0);
    signal s_WB_Data  : std_logic_vector(15 downto 0);

    signal s_Z, s_N, s_O, s_C : std_logic;

begin


    -- UNIDADE DE CONTROLO


    UC: Unidade_Controlo port map (
        Instruction => Instruction,
        Rd_addr     => s_Rd_addr,
        Rs1_addr    => s_Rs1_addr,
        Rs2_addr    => s_Rs2_addr,
        RegWrite    => s_RegWrite,
        OpCode_ALU  => s_OpCode_ALU,
        ALU_Src     => s_ALU_Src,
        Imm_8bit    => s_Imm_8bit,
        MemWrite    => s_MemWrite
    );

    -- EXTENSÃO DE SINAL

    SE: Extensao_Sinal port map (
        Data_In  => s_Imm_8bit,
        Data_Out => s_Imm_Ext
    );

    -- BANCO DE REGISTOS

    RF: Banco_Registos port map (
        Clock     => Clock,
        Reset     => Reset,
        RegWrite  => s_RegWrite,
        Rs1       => s_Rs1_addr,
        Rs2       => s_Rs2_addr,
        Rd        => s_Rd_addr,
        Data_In   => s_WB_Data,
        Data_Out1 => s_Read1,
        Data_Out2 => s_Read2
    );

    -- MUX OPERANDO B DA ALU

    MUX_ALU: MUX2 port map (
        Sel => s_ALU_Src,
        A   => s_Read2,
        B   => s_Imm_Ext,
        Y   => s_ALU_B
    );

    -- ALU

    ALU: ALU_Completa port map (
        A_in      => s_Read1,
        B_in      => s_ALU_B,
        OpCode_in => s_OpCode_ALU,
        R_out     => s_ALU_Res,
        Z_flag    => s_Z,
        N_flag    => s_N,
        O_flag    => s_O,
        C_flag    => s_C
    );

    -- MEMÓRIA DE DADOS (WriteEnable)

    DM: Memoria_Dados port map (
        Addr        => s_ALU_Res,
        WriteData   => s_Read2,
        WriteEnable => s_MemWrite,
        ReadData    => s_Mem_Out
    );

    -- WRITE BACK

    s_WB_Data <= s_Mem_Out when s_OpCode_ALU = "1000" -- LOAD
             else s_ALU_Res;


    Output_Data <= s_WB_Data;

end Structural;
