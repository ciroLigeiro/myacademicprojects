library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ALU_Completa is
    port (
        A_in      : in  STD_LOGIC_VECTOR(15 downto 0);
        B_in      : in  STD_LOGIC_VECTOR(15 downto 0);
        OpCode_in : in  STD_LOGIC_VECTOR(3 downto 0);
        R_out     : out STD_LOGIC_VECTOR(15 downto 0);
        Z_flag    : out STD_LOGIC;
        N_flag    : out STD_LOGIC;
        O_flag    : out STD_LOGIC;
        C_flag    : out STD_LOGIC
    );
end ALU_Completa;

architecture Structural of ALU_Completa is

    -- Declaração das Unidades
    component Unidade_Aritmetica
        port (
            a, b : in STD_LOGIC_VECTOR(15 downto 0);
            op   : in std_logic;
            y    : out STD_LOGIC_VECTOR(15 downto 0);
            C, O, Z, N : out std_logic
        );
    end component;

    component Unidade_Logica
        port (
            A, B    : in std_logic_vector(15 downto 0);
            op_code : in std_logic_vector(1 downto 0);
            Y       : out std_logic_vector(15 downto 0)
        );
    end component;

    component Unidade_Deslocamento
        port (
            A       : in std_logic_vector(15 downto 0);
            op_code : in std_logic;
            Y       : out std_logic_vector(15 downto 0);
            C_out   : out std_logic
        );
    end component;

    -- Sinais internos
    signal res_arit, res_logic, res_shift, res_final : std_logic_vector(15 downto 0);
    signal c_arit, o_arit, z_arit, n_arit : std_logic;
    signal ctrl_arit  : std_logic;
    signal ctrl_logic : std_logic_vector(1 downto 0);
    signal ctrl_shift : std_logic;
    signal c_shift : std_logic;

begin

    -- Descodificação de Sinais
    ctrl_arit <= OpCode_in(0); -- 0=ADD, 1=SUB
    
    process(OpCode_in)
    begin
        if OpCode_in = "0100" then
            ctrl_logic <= "10"; -- NOT
        else
            ctrl_logic(1) <= '0';
            ctrl_logic(0) <= OpCode_in(0); -- AND/OR
        end if;
    end process;

    ctrl_shift <= not OpCode_in(0); -- Left/Right


    U_ARIT : Unidade_Aritmetica port map (
        a  => A_in,    -- O sinal A_in liga à porta 'a'
        b  => B_in,    -- O sinal B_in liga à porta 'b'
        op => ctrl_arit,
        y  => res_arit,
        C  => c_arit, O => o_arit, Z => z_arit, N => n_arit
    );

    U_LOGIC : Unidade_Logica port map (
        A => A_in, B => B_in, op_code => ctrl_logic, Y => res_logic
    );

    U_SHIFT : Unidade_Deslocamento port map (
        A       => A_in, 
        op_code => ctrl_shift, 
        Y       => res_shift,
        C_out   => c_shift 
    );

    -- MUX Final
    process(OpCode_in, res_arit, res_logic, res_shift)
    begin
        case OpCode_in is
            when "0000" | "0001" => res_final <= res_arit;         -- ADD, SUB
            when "0010" | "0011" | "0100" => res_final <= res_logic; -- AND, OR, NOT
            when "0101" | "0110" => res_final <= res_shift;        -- SHL, SHR
            when others => res_final <= (others => '0');
        end case;
    end process;

    R_out <= res_final;
    
    -- MUX das Flags
    process(OpCode_in, c_arit, o_arit, c_shift)
        begin
            -- Overflow (O): Só existe na aritmética
            if (OpCode_in = "0000" or OpCode_in = "0001") then
                O_flag <= o_arit;
            else
                O_flag <= '0';
            end if;
    
            -- Carry (C): Existe na aritmética E no deslocamento
            if (OpCode_in = "0000" or OpCode_in = "0001") then
                C_flag <= c_arit; 
            elsif (OpCode_in = "0101" or OpCode_in = "0110") then -- SHL ou SHR
                C_flag <= c_shift;
            else
                C_flag <= '0';
            end if;
        end process;
        
    Z_flag <= '1' when res_final = x"0000" else '0';
    N_flag <= res_final(15);
end Structural;