library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Unidade_Controlo is
    Port (
        Instruction : in  STD_LOGIC_VECTOR (15 downto 0);
        Rd_addr     : out STD_LOGIC_VECTOR (2 downto 0);
        Rs1_addr    : out STD_LOGIC_VECTOR (2 downto 0);
        Rs2_addr    : out STD_LOGIC_VECTOR (2 downto 0);
        RegWrite    : out STD_LOGIC;
        OpCode_ALU  : out STD_LOGIC_VECTOR (3 downto 0);
        ALU_Src     : out STD_LOGIC;
        Imm_8bit    : out STD_LOGIC_VECTOR (7 downto 0);
        MemWrite    : out STD_LOGIC   -- WriteEnable
    );
end Unidade_Controlo;

architecture Behavioral of Unidade_Controlo is

    signal opcode : std_logic_vector(3 downto 0);

begin

    -- Campos fixos
    opcode     <= Instruction(15 downto 12);
    OpCode_ALU <= opcode;
    Imm_8bit   <= Instruction(7 downto 0);
    Rd_addr    <= Instruction(11 downto 9);

    process(Instruction, opcode)
    begin
        -- Defaults (para instruções aritméticas/lógicas)
        RegWrite <= '1';
        MemWrite <= '0';
        ALU_Src  <= '0';

        -- ISA tipo acumulador: por omissão, Rs1 = Rd
        Rs1_addr <= Instruction(11 downto 9);
        Rs2_addr <= Instruction(2 downto 0);  -- segundo operando em instruções reg-reg

        case opcode is

            -- LOAD: Rd <- Mem[Imm]
            when "1000" =>
                RegWrite <= '1';
                MemWrite <= '0';  -- leitura
                ALU_Src  <= '1';
                Rs2_addr <= (others => '0');

            -- STORE: Mem[Imm] <- Rd
            when "1001" =>
                RegWrite <= '0';
                MemWrite <= '1';  -- escrita
                ALU_Src  <= '1';
                Rs1_addr <= Instruction(11 downto 9);
                Rs2_addr <= Instruction(11 downto 9);

            -- ALU
            when others =>
                if Instruction(8) = '1' then
                    ALU_Src <= '1';
                else
                    ALU_Src <= '0';
                end if;
        end case;
    end process;

end Behavioral;
