library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Memoria_Dados is
    Port (
        Addr        : in  STD_LOGIC_VECTOR (15 downto 0);
        WriteData   : in  STD_LOGIC_VECTOR (15 downto 0);
        WriteEnable : in  STD_LOGIC; -- 1 = escrita, 0 = leitura
        ReadData    : out STD_LOGIC_VECTOR (15 downto 0)
    );
end Memoria_Dados;

architecture Behavioral of Memoria_Dados is
    type mem_array is array (0 to 255) of STD_LOGIC_VECTOR(15 downto 0);
    signal mem : mem_array := (others => (others => '0'));
begin

    -- Escrita ASSÍNCRONA (STORE)
    process(Addr, WriteData, WriteEnable)
    begin
        if WriteEnable = '1' then
            mem(to_integer(unsigned(Addr(7 downto 0)))) <= WriteData;
        end if;
    end process;

    -- Leitura ASSÍNCRONA (LOAD)
    process(Addr, WriteEnable, mem)
    begin
        if WriteEnable = '0' then
            ReadData <= mem(to_integer(unsigned(Addr(7 downto 0))));
        else
            ReadData <= (others => '0');
        end if;
    end process;

end Behavioral;
