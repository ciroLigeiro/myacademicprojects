library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Unidade_Logica is
    port (
        A, B : in  std_logic_vector(15 downto 0);
        op_code  : in  std_logic_vector(1 downto 0); -- Selecionador da operacao logica
        Y    : out std_logic_vector(15 downto 0)
    );
end Unidade_Logica;

architecture Behavioral of Unidade_Logica is
begin
    process(A, B, op_code)
    begin
        case op_code is
            when "00" =>   Y <= A and B; -- AND
            when "01" =>   Y <= A or B;  -- OR
            when "10" =>   Y <= not A;   -- NOT (B ignorado)
            when others => Y <= (others => '0');
        end case;
    end process;
end Behavioral;