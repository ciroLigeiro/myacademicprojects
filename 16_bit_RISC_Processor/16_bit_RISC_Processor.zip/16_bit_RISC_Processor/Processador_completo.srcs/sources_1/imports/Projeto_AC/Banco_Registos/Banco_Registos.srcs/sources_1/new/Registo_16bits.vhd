library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Registo_16 is
    Port ( 
        Clock : in STD_LOGIC;
        Reset : in STD_LOGIC;
        En    : in STD_LOGIC;
        D     : in STD_LOGIC_VECTOR (15 downto 0);
        Q     : out STD_LOGIC_VECTOR (15 downto 0)
    );
end Registo_16;

architecture Behavioral of Registo_16 is
    signal Q_interno : std_logic_vector(15 downto 0) := (others => '0');
begin

    process(Clock)
    begin
        if falling_edge(Clock) then
            if Reset = '1' then
                Q_interno <= (others => '0');
            elsif En = '1' then
                Q_interno <= D;
            end if;
        end if;
    end process;

    Q <= Q_interno;

end Behavioral;
