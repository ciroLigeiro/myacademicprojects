library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL; -- Necessário para converter bits para index (to_integer)

entity Banco_Registos is
    Port ( 
        Clock     : in STD_LOGIC;
        Reset     : in STD_LOGIC;
        RegWrite  : in STD_LOGIC; -- Sinal global de escrita (En)
        
        -- Seletores de registos (3 bits para selecionar 1 de 8)
        Rs1       : in STD_LOGIC_VECTOR (2 downto 0); -- Ler Registo 1
        Rs2       : in STD_LOGIC_VECTOR (2 downto 0); -- Ler Registo 2
        Rd        : in STD_LOGIC_VECTOR (2 downto 0); -- Registo de Destino (Escrita)
        
        -- Dados
        Data_In   : in STD_LOGIC_VECTOR (15 downto 0);  -- Dados para escrever
        Data_Out1 : out STD_LOGIC_VECTOR (15 downto 0); -- Dados lidos do Rs1
        Data_Out2 : out STD_LOGIC_VECTOR (15 downto 0)  -- Dados lidos do Rs2
    );
end Banco_Registos;

architecture Structural of Banco_Registos is

    -- 1. Declarar o componente Registo_16
    component Registo_16
        Port ( 
            Clock : in STD_LOGIC;
            En    : in STD_LOGIC;
            Reset : in STD_LOGIC;
            D     : in STD_LOGIC_VECTOR (15 downto 0);
            Q     : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    -- Array para guardar as saídas de todos os 8 registos
    type Reg_Array_Type is array (0 to 7) of std_logic_vector(15 downto 0);
    signal reg_outputs : Reg_Array_Type;

    -- Sinal para controlar o Enable individual de cada registo
    signal write_enables : std_logic_vector(7 downto 0);

begin

    -- 2. Lógica de Descodificação de Escrita (Decoder)
    -- Só ativa o bit correspondente se RegWrite estiver ativo e o índice for igual ao Rd.
    process(RegWrite, Rd)
    begin
        write_enables <= (others => '0'); -- Reset a todos
        if RegWrite = '1' then
            -- Ativa apenas o bit correspondente ao registo de destino (Rd)
            write_enables(to_integer(unsigned(Rd))) <= '1';
        end if;
    end process;

    -- 3. Instanciação dos 8 Registos (R0 a R7)
    -- Utilizamos um loop "generate" para não escrever o código 8 vezes,
    GEN_REGISTERS: for i in 0 to 7 generate
        REG_I : Registo_16 port map (
            Clock => Clock,
            Reset => Reset,
            En    => write_enables(i), -- Cada registo recebe o seu enable individual
            D     => Data_In,          -- Todos recebem o mesmo dado de entrada
            Q     => reg_outputs(i)    -- Cada um escreve na sua posição do array
        );
    end generate;

    -- 4. Multiplexers de Leitura (MUX)
    -- Tem 8 entradas.
    -- Selecionam qual valor do array 'reg_outputs' vai para a saída.
    
    Data_Out1 <= reg_outputs(to_integer(unsigned(Rs1)));
    Data_Out2 <= reg_outputs(to_integer(unsigned(Rs2)));

end Structural;