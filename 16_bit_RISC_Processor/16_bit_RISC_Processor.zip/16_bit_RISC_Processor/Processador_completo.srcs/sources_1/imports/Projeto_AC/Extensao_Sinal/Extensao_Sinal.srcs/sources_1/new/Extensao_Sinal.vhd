library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL; -- Essencial para a função 'resize'

entity Extensao_Sinal is
    Port ( 
        Data_In  : in  STD_LOGIC_VECTOR (7 downto 0);  -- Entrada de 8 bits (Imediato)
        Data_Out : out STD_LOGIC_VECTOR (15 downto 0) -- Saída de 16 bits
    );
end Extensao_Sinal;

architecture Behavioral of Extensao_Sinal is
begin
    -- 'signed(Data_In)': Diz ao VHDL para tratar os bits como número com sinal.
    --  'resize(..., 16)': Aumenta para 16 bits preenchendo automaticamente com o bit de sinal.
    
    Data_Out <= std_logic_vector(resize(signed(Data_In), 16));     -- 'std_logic_vector(...)': Converte de volta para bits normais.

end Behavioral;