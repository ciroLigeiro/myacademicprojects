library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX2 is
    Port ( 
        Sel : in  STD_LOGIC;                      -- O seletor (Vem da Unidade de Controlo)
        A   : in  STD_LOGIC_VECTOR (15 downto 0); -- Entrada 0 (Vem da ALU)
        B   : in  STD_LOGIC_VECTOR (15 downto 0); -- Entrada 1 (Vem da Memória de Dados)
        Y   : out STD_LOGIC_VECTOR (15 downto 0)  -- Saída (Vai para o Write Data dos Registos)
    );
end MUX2;

architecture Behavioral of MUX2 is
begin
    -- Se Sel='0' passa A (ALU), se Sel='1' passa B (Memória)
    Y <= A when Sel = '0' else B;
end Behavioral;