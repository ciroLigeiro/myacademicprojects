library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Unidade_Deslocamento is
    port (
        A       : in  std_logic_vector(15 downto 0);
        op_code : in  std_logic; -- 0 = Esquerda (SHL), 1 = Direita (SHR Aritmético)
        Y       : out std_logic_vector(15 downto 0);
        C_out   : out std_logic  -- Nova saída para o Carry
    );
end Unidade_Deslocamento;

architecture Behavioral of Unidade_Deslocamento is
begin
    process(A, op_code)
    begin
        if op_code = '0' then
            -- Shift Left Logic
            -- O bit 15 é o que "cai fora" e vira o Carry
            C_out <= A(15);
            Y     <= std_logic_vector(shift_left(unsigned(A), 1));
        else
            -- Shift Right Arithmetic
            -- O bit 0 é o que "cai fora" e vira o Carry
            C_out <= A(0);
            Y     <= std_logic_vector(shift_right(signed(A), 1));
        end if;
    end process;
end Behavioral;