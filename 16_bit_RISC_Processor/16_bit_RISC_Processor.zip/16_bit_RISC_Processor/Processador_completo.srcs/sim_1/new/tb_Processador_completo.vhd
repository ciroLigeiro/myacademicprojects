library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_Processador_Completo is
end tb_Processador_Completo;

architecture Sim of tb_Processador_Completo is

    component Processador_Completo
        Port (
            Clock       : in  STD_LOGIC;
            Reset       : in  STD_LOGIC;
            Instruction : in  STD_LOGIC_VECTOR (15 downto 0);
            Output_Data : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    signal Clock       : std_logic := '0';
    signal Reset       : std_logic := '0';
    signal Instruction : std_logic_vector(15 downto 0) := (others => '0');
    signal Output_Data : std_logic_vector(15 downto 0);

    constant CLK_PERIOD : time := 20 ns;

    -- Opcodes
    constant OP_ADD   : std_logic_vector(3 downto 0) := "0000";
    constant OP_SUB   : std_logic_vector(3 downto 0) := "0001";
    constant OP_AND   : std_logic_vector(3 downto 0) := "0010";
    constant OP_OR    : std_logic_vector(3 downto 0) := "0011";
    constant OP_NOT   : std_logic_vector(3 downto 0) := "0100";
    constant OP_SHL   : std_logic_vector(3 downto 0) := "0101";
    constant OP_SHR   : std_logic_vector(3 downto 0) := "0110";
    constant OP_LOAD  : std_logic_vector(3 downto 0) := "1000";
    constant OP_STORE : std_logic_vector(3 downto 0) := "1001";

begin

    DUT: Processador_Completo port map (
        Clock       => Clock,
        Reset       => Reset,
        Instruction => Instruction,
        Output_Data => Output_Data
    );

    -- Clock
    clk_proc : process
    begin
        Clock <= '0';
        wait for CLK_PERIOD/2;
        Clock <= '1';
        wait for CLK_PERIOD/2;
    end process;

    stim_proc : process
    begin
        report "=== INICIO DO TESTBENCH COMPLETO ===" severity note;

        -- RESET
        Reset <= '1';
        wait for CLK_PERIOD * 2;
        Reset <= '0';
        wait for CLK_PERIOD;

        -- ADD R1, #10
        Instruction <= OP_ADD & "001" & '1' & "00001010";
        wait for CLK_PERIOD;
        report "ADD R1,#10 = " & integer'image(to_integer(signed(Output_Data)));

        -- ADD R2, #5
        Instruction <= OP_ADD & "010" & '1' & "00000101";
        wait for CLK_PERIOD;
        report "ADD R2,#5 = " & integer'image(to_integer(signed(Output_Data)));

        -- ADD R1, R2
        Instruction <= OP_ADD & "001" & '0' & "00000" & "010";
        wait for CLK_PERIOD;
        report "ADD R1,R2 = " & integer'image(to_integer(signed(Output_Data)));

        -- SUB R1, R2
        Instruction <= OP_SUB & "001" & '0' & "00000" & "010";
        wait for CLK_PERIOD;
        report "SUB R1,R2 = " & integer'image(to_integer(signed(Output_Data)));

        -- AND R1, R2
        Instruction <= OP_AND & "001" & '0' & "00000" & "010";
        wait for CLK_PERIOD;
        report "AND R1,R2 = " & integer'image(to_integer(signed(Output_Data)));

        -- OR R1, R2
        Instruction <= OP_OR & "001" & '0' & "00000" & "010";
        wait for CLK_PERIOD;
        report "OR R1,R2 = " & integer'image(to_integer(signed(Output_Data)));

        -- NOT R1
        Instruction <= OP_NOT & "001" & '0' & "00000000";
        wait for CLK_PERIOD;
        report "NOT R1 = " & integer'image(to_integer(signed(Output_Data)));

        -- SHL R1
        Instruction <= OP_SHL & "001" & '0' & "00000000";
        wait for CLK_PERIOD;
        report "SHL R1 = " & integer'image(to_integer(signed(Output_Data)));

        -- SHR R1
        Instruction <= OP_SHR & "001" & '0' & "00000000";
        wait for CLK_PERIOD;
        report "SHR R1 = " & integer'image(to_integer(signed(Output_Data)));

        -- STORE R1 -> MEM[4]
        Instruction <= OP_STORE & "001" & '1' & "00000100";
        wait for CLK_PERIOD;
        report "STORE R1 -> MEM[4]";

        -- LOAD MEM[4] -> R3
        Instruction <= OP_LOAD & "011" & '1' & "00000100";
        wait for CLK_PERIOD;
        report "LOAD MEM[4] -> R3 = " & integer'image(to_integer(signed(Output_Data)));

        report "=== FIM DO TESTBENCH ===" severity note;
        wait;
    end process;

end Sim;
