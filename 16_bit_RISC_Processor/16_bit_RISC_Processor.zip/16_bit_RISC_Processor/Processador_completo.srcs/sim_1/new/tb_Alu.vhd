library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Declaração da entidade de teste (vazia)
entity tb_ALU_Completa is
end entity;

architecture sim of tb_ALU_Completa is

    -- Sinais para ligar ao DUT (Device Under Test)
    signal A_in, B_in : std_logic_vector(15 downto 0) := (others => '0');
    signal OpCode_in  : std_logic_vector(3 downto 0)  := (others => '0');

    signal R_out      : std_logic_vector(15 downto 0);
    signal Z_flag, N_flag, O_flag, C_flag : std_logic;

begin

    -- Instanciação do componente a testar 
    -- Utilizando 'entity work' para evitar declarar componente
    DUT: entity work.ALU_Completa
    port map (
        A_in      => A_in,
        B_in      => B_in,
        OpCode_in => OpCode_in,
        R_out     => R_out,
        Z_flag    => Z_flag,
        N_flag    => N_flag,
        O_flag    => O_flag,
        C_flag    => C_flag
    );


    stim_proc: process
    begin
        -- Mensagem de início
        report "=== Inicio da simulacao ===" severity note;

        -- Teste 1: Soma (ADD) -> 10 + 5 = 15

        A_in      <= std_logic_vector(to_signed(10, 16));
        B_in      <= std_logic_vector(to_signed(5, 16));
        OpCode_in <= "0000"; -- ADD
        
        wait for 1 ns; -- Tempo de espera para estabilização

        report "Teste 1: 10 + 5 -> Resultado = " & integer'image(to_integer(signed(R_out))) & 
               ", Carry = " & std_logic'image(C_flag) & 
               ", Overflow = " & std_logic'image(O_flag) & 
               ", Zero = " & std_logic'image(Z_flag) & 
               ", Negativo = " & std_logic'image(N_flag) & ".";

        -- Teste 2: Subtração (SUB) -> 20 - 20 = 0 (Teste Flag Zero)

        A_in      <= std_logic_vector(to_signed(20, 16));
        B_in      <= std_logic_vector(to_signed(20, 16));
        OpCode_in <= "0001"; -- SUB
        
        wait for 1 ns;

        report "Teste 2: 20 - 20 -> Resultado = " & integer'image(to_integer(signed(R_out))) & 
               ", Zero = " & std_logic'image(Z_flag) & ".";


        -- Teste 3: Lógica AND -> 15 AND 5 = 5 (0000...1111 AND 0000...0101)

        A_in      <= std_logic_vector(to_signed(15, 16));
        B_in      <= std_logic_vector(to_signed(5, 16));
        OpCode_in <= "0010"; -- AND
        
        wait for 1 ns;

        report "Teste 3: 15 AND 5 -> Resultado = " & integer'image(to_integer(signed(R_out))) & ".";


        -- Teste 4: Shift Left (SHL) -> x8001 deslocado à esquerda
        -- 1000...0001 -> O '1' mais à esquerda deve ir para o CARRY

        A_in      <= x"8001"; -- Hexadecimal para 1000...0001
        B_in      <= x"0000"; -- Ignorado
        OpCode_in <= "0101"; -- SHL
        
        wait for 1 ns;

        -- Nota: Convertemos para inteiro para ver o valor, mas o importante aqui é o Carry
        report "Teste 4: SHL x8001 -> Resultado (int) = " & integer'image(to_integer(signed(R_out))) & 
               ", Carry (esperado '1') = " & std_logic'image(C_flag) & ".";


        -- Teste 5: Shift Right (SHR) -> x0003 deslocado à direita
        -- ...0011 -> O '1' mais à direita deve ir para o CARRY

        A_in      <= x"0003"; 
        OpCode_in <= "0110"; -- SHR
        
        wait for 1 ns;

        report "Teste 5: SHR x0003 -> Resultado (int) = " & integer'image(to_integer(signed(R_out))) & 
               ", Carry (esperado '1') = " & std_logic'image(C_flag) & ".";

        -- Fim da Simulação-----
        
        report "=== Fim da simulacao ===" severity note;
        wait; -- Parar a simulação

    end process;

end architecture sim;